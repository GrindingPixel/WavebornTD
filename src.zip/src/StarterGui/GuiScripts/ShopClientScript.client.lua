--// Services
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MarketplaceService = game:GetService("MarketplaceService")

--// Module
local ItemData = require(ReplicatedStorage.Modules.ItemDataModule)

--// GUI
local player = Players.LocalPlayer
local gui = player:WaitForChild("PlayerGui"):WaitForChild("ShopGui")
local panel = gui:WaitForChild("ShopPanel")
local template = panel:WaitForChild("ProductTemplate")
local grid = panel:WaitForChild("ProductGrid")

--// Debug
local DEBUG = true
local function log(...) if DEBUG then print("[🛒 ShopClient]", ...) end end
local function warnf(...) if DEBUG then warn("[🛒 ShopClient]", ...) end end

--// Lokale Produktzuordnung (Client kennt ID + ItemId)
local Products = {
	{
		productId = 12345678,
		itemId = "Scroll_Alpha",
	},
	{
		productId = 23456789,
		itemId = "Evo_StarPiece",
	},
}

--// Funktionen
local function createProduct(product)
	local meta = ItemData.GetMeta(product.itemId)
	if not meta then
		warnf("Unbekanntes Item:", product.itemId)
		return
	end

	local clone = template:Clone()
	clone.Visible = true
	clone.Name = product.itemId
	clone.Parent = grid

	-- Inhalte setzen
	clone.ItemName.Text = meta.displayName or product.itemId
	clone:SetAttribute("TooltipId", product.itemId)

	if clone:FindFirstChild("ItemImage") and meta.iconId then
		clone.ItemImage.Image = meta.iconId
	end

	-- Kaufen
	local buyButton = clone:FindFirstChild("BuyButton")
	if buyButton then
		buyButton.MouseButton1Click:Connect(function()
			log("Kaufe:", meta.displayName, "→", product.productId)
			MarketplaceService:PromptProductPurchase(player, product.productId)
		end)
	end
end

--// Init
task.defer(function()
	for _, product in ipairs(Products) do
		createProduct(product)
	end
end)
